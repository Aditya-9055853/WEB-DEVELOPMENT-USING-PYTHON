import logging
import stripe
import os
from flask import (
    render_template, redirect, url_for, flash, request, 
    session, jsonify, abort, current_app
)
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy.exc import SQLAlchemyError
from app import app, db
from models import User, Book, CartItem, Order, OrderItem
from api import (
    search_google_books, get_book_details, 
    get_book_recommendations, search_local_books
)
from utils import calculate_cart_total, validate_book_data
from cache import cache_data, get_cached_data

# Configure Stripe API key
stripe.api_key = app.config["STRIPE_SECRET_KEY"]

# Homepage route
@app.route('/')
def index():
    """Homepage showing featured books and search form"""
    # Get featured books (latest additions)
    featured_books = Book.query.order_by(Book.created_at.desc()).limit(6).all()
    return render_template('index.html', featured_books=featured_books)


# Search routes
@app.route('/search')
def search():
    """Search for books using Google Books API and local database"""
    query = request.args.get('query', '')
    
    if not query:
        return render_template('search_results.html', books=[], query='')
    
    # First check local database
    local_books = search_local_books(query)
    
    # If not enough results, also search Google Books API
    if len(local_books) < 10:
        # Create a cache key for the search query
        cache_key = f"search_{query.replace(' ', '_')}"
        # Try to get results from cache first
        cached_results = get_cached_data(cache_key)
        
        if cached_results:
            api_books = cached_results
        else:
            # If not in cache, call the API
            api_books = search_google_books(query)
            # Cache the results for future use
            if api_books:
                cache_data(cache_key, api_books, 3600)  # Cache for 1 hour

        # Combine local and API results, avoiding duplicates
        google_book_ids = [book.google_books_id for book in local_books]
        for book in api_books:
            if book['id'] not in google_book_ids:
                # This is a new book not in our database
                book['in_database'] = False
                local_books.append(book)
    
    return render_template('search_results.html', books=local_books, query=query)


@app.route('/book/<string:book_id>')
def book_detail(book_id):
    """Show detailed information about a book"""
    # Check if it's a database ID (numeric) or Google Books ID
    try:
        book_id_int = int(book_id)
        # It's a numeric ID, fetch from our database
        book = Book.query.get_or_404(book_id_int)
        book_dict = book.to_dict()
        is_in_database = True
    except ValueError:
        # It's a Google Books ID, fetch from API
        # Try cache first
        cache_key = f"book_{book_id}"
        book_dict = get_cached_data(cache_key)
        
        if not book_dict:
            # Not in cache, fetch from API
            book_dict = get_book_details(book_id)
            # Cache the result
            if book_dict:
                cache_data(cache_key, book_dict, 86400)  # Cache for 24 hours
                
        if not book_dict:
            abort(404)
            
        is_in_database = False
        # Check if this book exists in our database with a different ID
        existing_book = Book.query.filter_by(google_books_id=book_id).first()
        if existing_book:
            book_dict = existing_book.to_dict()
            is_in_database = True
    
    # Get recommendations for this book
    recommendations = []
    if is_in_database:
        # Create a cache key for recommendations
        cache_key = f"recommendations_{book_id}"
        recommendations = get_cached_data(cache_key)
        
        if not recommendations:
            # Not in cache, fetch from API
            recommendations = get_book_recommendations(book_dict)
            # Cache the results
            if recommendations:
                cache_data(cache_key, recommendations, 43200)  # Cache for 12 hours
    
    # Check if book is in cart
    in_cart = False
    cart_quantity = 0
    if current_user.is_authenticated:
        cart_item = CartItem.query.filter_by(
            user_id=current_user.id, 
            book_id=book_dict['id'] if is_in_database else None
        ).first()
        if cart_item:
            in_cart = True
            cart_quantity = cart_item.quantity

    return render_template(
        'book_detail.html', 
        book=book_dict, 
        is_in_database=is_in_database, 
        recommendations=recommendations,
        in_cart=in_cart,
        cart_quantity=cart_quantity
    )


# Admin route to add books to database
@app.route('/admin/add_book', methods=['POST'])
@login_required
def add_book():
    """Add a book to the database from Google Books API"""
    if not current_user.is_admin:
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('index'))
    
    google_book_id = request.form.get('google_book_id')
    price = request.form.get('price')
    stock = request.form.get('stock')
    
    if not google_book_id or not price or not stock:
        flash('Missing required fields', 'danger')
        return redirect(request.referrer or url_for('index'))
    
    try:
        price = float(price)
        stock = int(stock)
    except ValueError:
        flash('Invalid price or stock value', 'danger')
        return redirect(request.referrer or url_for('index'))
    
    # Check if book already exists
    existing_book = Book.query.filter_by(google_books_id=google_book_id).first()
    if existing_book:
        flash('This book already exists in the database', 'warning')
        return redirect(url_for('book_detail', book_id=existing_book.id))
    
    # Fetch book details from Google Books API
    book_data = get_book_details(google_book_id)
    if not book_data:
        flash('Failed to fetch book details from Google Books API', 'danger')
        return redirect(request.referrer or url_for('index'))
    
    # Create new book in database
    try:
        book = Book(
            google_books_id=google_book_id,
            title=book_data.get('title', 'Unknown Title'),
            authors=book_data.get('authors', ''),
            publisher=book_data.get('publisher', ''),
            published_date=book_data.get('published_date', ''),
            description=book_data.get('description', ''),
            isbn=book_data.get('isbn', ''),
            page_count=book_data.get('page_count', 0),
            categories=book_data.get('categories', ''),
            thumbnail_url=book_data.get('thumbnail_url', ''),
            price=price,
            stock=stock
        )
        db.session.add(book)
        db.session.commit()
        flash('Book added successfully', 'success')
        return redirect(url_for('book_detail', book_id=book.id))
    except SQLAlchemyError as e:
        db.session.rollback()
        logging.error(f"Database error adding book: {e}")
        flash('Error adding book to database', 'danger')
        return redirect(request.referrer or url_for('index'))


# Cart routes
@app.route('/cart')
@login_required
def view_cart():
    """Display the user's shopping cart"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    cart_books = []
    total = 0
    
    for item in cart_items:
        book = item.book
        if book and book.stock >= item.quantity:
            subtotal = book.price * item.quantity
            cart_books.append({
                'id': book.id,
                'title': book.title,
                'author': book.authors,
                'price': book.price,
                'quantity': item.quantity,
                'subtotal': subtotal,
                'thumbnail_url': book.thumbnail_url
            })
            total += subtotal
    
    return render_template('cart.html', cart_items=cart_books, total=total)


@app.route('/cart/add', methods=['POST'])
@login_required
def add_to_cart():
    """Add a book to the shopping cart"""
    book_id = request.form.get('book_id')
    quantity = int(request.form.get('quantity', 1))
    
    if not book_id or quantity <= 0:
        flash('Invalid request', 'danger')
        return redirect(request.referrer or url_for('index'))
    
    # Check if book exists and has stock
    book = Book.query.get_or_404(book_id)
    if book.stock < quantity:
        flash('Not enough stock available', 'warning')
        return redirect(request.referrer or url_for('book_detail', book_id=book_id))
    
    # Check if already in cart
    cart_item = CartItem.query.filter_by(user_id=current_user.id, book_id=book_id).first()
    if cart_item:
        # Update quantity if already in cart
        cart_item.quantity += quantity
        if cart_item.quantity > book.stock:
            cart_item.quantity = book.stock
            flash('Adjusted quantity based on available stock', 'warning')
    else:
        # Add new item to cart
        cart_item = CartItem(user_id=current_user.id, book_id=book_id, quantity=quantity)
        db.session.add(cart_item)
    
    try:
        db.session.commit()
        flash('Book added to cart', 'success')
    except SQLAlchemyError as e:
        db.session.rollback()
        logging.error(f"Error adding to cart: {e}")
        flash('Error adding book to cart', 'danger')
    
    return redirect(request.referrer or url_for('view_cart'))


@app.route('/cart/update', methods=['POST'])
@login_required
def update_cart():
    """Update cart item quantities"""
    cart_items = request.form.getlist('cart_item_id')
    quantities = request.form.getlist('quantity')
    
    if not cart_items or not quantities or len(cart_items) != len(quantities):
        flash('Invalid request', 'danger')
        return redirect(url_for('view_cart'))
    
    for i, item_id in enumerate(cart_items):
        try:
            quantity = int(quantities[i])
            if quantity <= 0:
                # Remove item if quantity is 0 or negative
                CartItem.query.filter_by(id=item_id, user_id=current_user.id).delete()
            else:
                cart_item = CartItem.query.filter_by(id=item_id, user_id=current_user.id).first()
                if cart_item:
                    # Check if quantity exceeds stock
                    if quantity > cart_item.book.stock:
                        quantity = cart_item.book.stock
                        flash(f'Quantity for {cart_item.book.title} adjusted to available stock', 'warning')
                    cart_item.quantity = quantity
        except (ValueError, TypeError):
            flash('Invalid quantity', 'danger')
    
    try:
        db.session.commit()
        flash('Cart updated', 'success')
    except SQLAlchemyError as e:
        db.session.rollback()
        logging.error(f"Error updating cart: {e}")
        flash('Error updating cart', 'danger')
    
    return redirect(url_for('view_cart'))


@app.route('/cart/remove/<int:item_id>', methods=['POST'])
@login_required
def remove_from_cart(item_id):
    """Remove an item from the cart"""
    cart_item = CartItem.query.filter_by(id=item_id, user_id=current_user.id).first()
    if not cart_item:
        flash('Item not found in cart', 'danger')
        return redirect(url_for('view_cart'))
    
    try:
        db.session.delete(cart_item)
        db.session.commit()
        flash('Item removed from cart', 'success')
    except SQLAlchemyError as e:
        db.session.rollback()
        logging.error(f"Error removing item from cart: {e}")
        flash('Error removing item from cart', 'danger')
    
    return redirect(url_for('view_cart'))


# Checkout and payment routes
@app.route('/checkout')
@login_required
def checkout():
    """Display checkout page"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    if not cart_items:
        flash('Your cart is empty', 'warning')
        return redirect(url_for('index'))
    
    # Calculate total
    total = calculate_cart_total(current_user.id)
    
    return render_template('checkout.html', 
                          cart_items=cart_items, 
                          total=total,
                          stripe_publishable_key=app.config["STRIPE_PUBLISHABLE_KEY"])


@app.route('/create-checkout-session', methods=['POST'])
@login_required
def create_checkout_session():
    """Create a Stripe checkout session"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    if not cart_items:
        flash('Your cart is empty', 'warning')
        return redirect(url_for('index'))
    
    # Prepare line items for Stripe
    line_items = []
    for item in cart_items:
        book = item.book
        line_items.append({
            'price_data': {
                'currency': 'usd',
                'product_data': {
                    'name': book.title,
                    'description': f"By {book.authors}" if book.authors else None,
                    'images': [book.thumbnail_url] if book.thumbnail_url else [],
                },
                'unit_amount': int(book.price * 100),  # Convert to cents
            },
            'quantity': item.quantity,
        })
    
    # Create a new order in pending state
    total = calculate_cart_total(current_user.id)
    order = Order(user_id=current_user.id, total_amount=total, status='pending')
    db.session.add(order)
    db.session.commit()
    
    # Create order items
    for item in cart_items:
        order_item = OrderItem(
            order_id=order.id,
            book_id=item.book_id,
            quantity=item.quantity,
            price=item.book.price
        )
        db.session.add(order_item)
    
    # Determine success and cancel URLs
    YOUR_DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN', request.host_url.rstrip('/'))
    if not YOUR_DOMAIN.startswith(('http://', 'https://')):
        YOUR_DOMAIN = 'https://' + YOUR_DOMAIN
    
    try:
        # Create the Stripe checkout session
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=YOUR_DOMAIN + url_for('checkout_success') + f'?session_id={{CHECKOUT_SESSION_ID}}&order_id={order.id}',
            cancel_url=YOUR_DOMAIN + url_for('checkout_cancel') + f'?order_id={order.id}',
            client_reference_id=str(order.id),
            metadata={'order_id': order.id}
        )
        
        # Update order with Stripe checkout ID
        order.stripe_checkout_id = checkout_session.id
        db.session.commit()
        
        # Redirect to Stripe's hosted checkout page
        return redirect(checkout_session.url, code=303)
    except Exception as e:
        logging.error(f"Stripe error: {e}")
        # Mark order as failed
        order.status = 'failed'
        db.session.commit()
        flash('Payment processing error. Please try again.', 'danger')
        return redirect(url_for('checkout'))


@app.route('/checkout/success')
@login_required
def checkout_success():
    """Handle successful checkout"""
    session_id = request.args.get('session_id')
    order_id = request.args.get('order_id')
    
    if not session_id or not order_id:
        flash('Invalid checkout session', 'danger')
        return redirect(url_for('index'))
    
    # Get the order
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first()
    if not order:
        flash('Order not found', 'danger')
        return redirect(url_for('index'))
    
    # Verify payment with Stripe
    try:
        checkout_session = stripe.checkout.Session.retrieve(session_id)
        
        # Update order status
        if checkout_session.payment_status == 'paid':
            order.status = 'paid'
            order.stripe_payment_id = checkout_session.payment_intent
            
            # Update book inventory
            for item in order.items:
                book = item.book
                book.stock = book.stock - item.quantity
            
            # Clear the user's cart
            CartItem.query.filter_by(user_id=current_user.id).delete()
            
            db.session.commit()
            flash('Payment completed successfully!', 'success')
        else:
            flash('Payment not completed yet. We will update your order soon.', 'info')
    except Exception as e:
        logging.error(f"Error verifying payment: {e}")
        flash('Error verifying payment. Please contact support.', 'danger')
    
    return render_template('success.html', order=order)


@app.route('/checkout/cancel')
@login_required
def checkout_cancel():
    """Handle cancelled checkout"""
    order_id = request.args.get('order_id')
    
    if order_id:
        order = Order.query.filter_by(id=order_id, user_id=current_user.id).first()
        if order and order.status == 'pending':
            order.status = 'cancelled'
            db.session.commit()
    
    flash('Checkout was cancelled. Your cart is still saved.', 'info')
    return render_template('cancel.html')


# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = 'remember' in request.form
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate form data
        error = None
        if not username or not email or not password:
            error = 'All fields are required'
        elif password != confirm_password:
            error = 'Passwords do not match'
        elif User.query.filter_by(username=username).first():
            error = 'Username already exists'
        elif User.query.filter_by(email=email).first():
            error = 'Email already registered'
        
        if error:
            flash(error, 'danger')
        else:
            # Create new user
            user = User(username=username, email=email)
            user.set_password(password)
            
            try:
                db.session.add(user)
                db.session.commit()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('login'))
            except SQLAlchemyError as e:
                db.session.rollback()
                logging.error(f"Error registering user: {e}")
                flash('Error creating account. Please try again.', 'danger')
    
    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))


@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    # Get user's order history
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('profile.html', user=current_user, orders=orders)


# Admin dashboard
@app.route('/admin')
@login_required
def admin_dashboard():
    """Admin dashboard page"""
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get stats for admin dashboard
    total_users = User.query.count()
    total_books = Book.query.count()
    total_orders = Order.query.count()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    # Books with low stock
    low_stock_books = Book.query.filter(Book.stock < 5).all()
    
    return render_template(
        'admin_dashboard.html',
        total_users=total_users,
        total_books=total_books,
        total_orders=total_orders,
        recent_orders=recent_orders,
        low_stock_books=low_stock_books
    )


# Error handlers

# Simple payment method for first-year students
@app.route('/create_pay_on_delivery_order', methods=['POST'])
@login_required
def create_pay_on_delivery_order():
    """Create a simple pay-on-delivery order"""
    # Get cart items
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    if not cart_items:
        flash('Your cart is empty', 'warning')
        return redirect(url_for('view_cart'))
    
    # Calculate total
    total = calculate_cart_total(current_user.id)
    
    # Create order in the database
    order = Order(
        user_id=current_user.id,
        total_amount=total,
        status='confirmed'  # directly mark as confirmed since it's pay-on-delivery
    )
    db.session.add(order)
    db.session.commit()
    
    # Create order items
    for item in cart_items:
        order_item = OrderItem(
            order_id=order.id,
            book_id=item.book_id,
            quantity=item.quantity,
            price=item.book.price
        )
        db.session.add(order_item)
    
    db.session.commit()
    
    # Clear the user's cart
    CartItem.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    
    # Redirect to success page with order ID
    return redirect(url_for('simple_payment_success', order_id=order.id))


@app.route('/simple_payment_success')
@login_required
def simple_payment_success():
    """Handle success for simple payment method"""
    order_id = request.args.get('order_id')
    
    if not order_id:
        flash('Invalid order information', 'danger')
        return redirect(url_for('index'))
    
    # Get the order
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first()
    if not order:
        flash('Order not found', 'danger')
        return redirect(url_for('index'))
    
    return render_template('simple_success.html', order=order)


@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, message='Page not found'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error_code=500, message='Server error'), 500
