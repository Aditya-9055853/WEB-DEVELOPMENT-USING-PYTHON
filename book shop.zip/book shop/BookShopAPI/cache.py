import json
import time
import logging
from flask import current_app

def cache_data(key, data, expiry=3600):
    """
    Cache data in Redis
    
    Args:
        key: Cache key
        data: Data to cache (will be JSON serialized)
        expiry: Expiry time in seconds (default: 1 hour)
        
    Returns:
        Boolean indicating success
    """
    # Check if Redis is enabled in the application
    if current_app.config.get('REDIS_ENABLED') is False:
        return False
        
    redis_client = current_app.config.get('REDIS_CLIENT')
    if not redis_client:
        return False
    
    try:
        # Convert data to JSON string
        json_data = json.dumps(data)
        # Store in Redis with expiry
        redis_client.setex(key, expiry, json_data)
        return True
    except Exception as e:
        logging.error(f"Redis cache error: {e}")
        return False


def get_cached_data(key):
    """
    Get data from Redis cache
    
    Args:
        key: Cache key
        
    Returns:
        Cached data or None if not found
    """
    # Check if Redis is enabled in the application
    if current_app.config.get('REDIS_ENABLED') is False:
        return None
        
    redis_client = current_app.config.get('REDIS_CLIENT')
    if not redis_client:
        return None
    
    try:
        # Get data from Redis
        data = redis_client.get(key)
        if data:
            # Decode and parse JSON
            return json.loads(data.decode('utf-8'))
        return None
    except Exception as e:
        logging.error(f"Redis cache retrieval error: {e}")
        return None


def clear_cache(key_pattern='*'):
    """
    Clear cache entries matching a pattern
    
    Args:
        key_pattern: Redis key pattern to match
        
    Returns:
        Number of keys cleared
    """
    # Check if Redis is enabled in the application
    if current_app.config.get('REDIS_ENABLED') is False:
        return 0
        
    redis_client = current_app.config.get('REDIS_CLIENT')
    if not redis_client:
        return 0
    
    try:
        # Get matching keys
        keys = redis_client.keys(key_pattern)
        if not keys:
            return 0
            
        # Delete keys
        return redis_client.delete(*keys)
    except Exception as e:
        logging.error(f"Redis cache clear error: {e}")
        return 0


def get_cache_stats():
    """
    Get cache statistics
    
    Returns:
        Dictionary with cache stats
    """
    # Check if Redis is enabled in the application
    if current_app.config.get('REDIS_ENABLED') is False:
        return {'status': 'disabled', 'message': 'Redis caching is disabled'}
        
    redis_client = current_app.config.get('REDIS_CLIENT')
    if not redis_client:
        return {'status': 'disconnected'}
    
    try:
        info = redis_client.info()
        stats = {
            'status': 'connected',
            'used_memory': info.get('used_memory_human', 'N/A'),
            'connected_clients': info.get('connected_clients', 'N/A'),
            'uptime_days': info.get('uptime_in_days', 'N/A')
        }
        return stats
    except Exception as e:
        logging.error(f"Redis stats error: {e}")
        return {'status': 'error', 'message': str(e)}
