from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


class User(UserMixin, db.Model):
    """User model for authentication and profile information"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    cart_items = db.relationship('CartItem', back_populates='user', lazy='dynamic', cascade='all, delete-orphan')
    orders = db.relationship('Order', back_populates='user', lazy='dynamic')
    
    def set_password(self, password):
        """Generate a password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check the password against its hash"""
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class Book(db.Model):
    """Book model to store information about books"""
    id = db.Column(db.Integer, primary_key=True)
    google_books_id = db.Column(db.String(128), unique=True, nullable=False)
    title = db.Column(db.String(256), nullable=False)
    authors = db.Column(db.String(256))
    publisher = db.Column(db.String(256))
    published_date = db.Column(db.String(64))
    description = db.Column(db.Text)
    isbn = db.Column(db.String(20))
    page_count = db.Column(db.Integer)
    categories = db.Column(db.String(256))
    thumbnail_url = db.Column(db.String(512))
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    cart_items = db.relationship('CartItem', back_populates='book', lazy='dynamic')
    order_items = db.relationship('OrderItem', back_populates='book', lazy='dynamic')
    
    def __repr__(self):
        return f'<Book {self.title}>'
    
    def to_dict(self):
        """Convert book to dictionary for API responses"""
        return {
            'id': self.id,
            'google_books_id': self.google_books_id,
            'title': self.title,
            'authors': self.authors,
            'publisher': self.publisher,
            'published_date': self.published_date,
            'description': self.description,
            'isbn': self.isbn,
            'page_count': self.page_count,
            'categories': self.categories,
            'thumbnail_url': self.thumbnail_url,
            'price': self.price,
            'stock': self.stock
        }


class CartItem(db.Model):
    """Model for items in a user's shopping cart"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', back_populates='cart_items')
    book = db.relationship('Book', back_populates='cart_items')
    
    def __repr__(self):
        return f'<CartItem {self.id}: {self.quantity} of book {self.book_id}>'


class Order(db.Model):
    """Model for customer orders"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    stripe_payment_id = db.Column(db.String(128))
    stripe_checkout_id = db.Column(db.String(128))
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(64), default='pending')  # pending, paid, shipped, delivered, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', back_populates='orders')
    items = db.relationship('OrderItem', back_populates='order', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Order {self.id}: ${self.total_amount} - {self.status}>'


class OrderItem(db.Model):
    """Model for items within an order"""
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    price = db.Column(db.Float, nullable=False)  # Price at time of purchase
    
    # Relationships
    order = db.relationship('Order', back_populates='items')
    book = db.relationship('Book', back_populates='order_items')
    
    def __repr__(self):
        return f'<OrderItem {self.id}: {self.quantity} of book {self.book_id}>'


class RecommendationCache(db.Model):
    """Model to cache book recommendations"""
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    recommendation_ids = db.Column(db.Text)  # Store as comma-separated IDs
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<RecommendationCache for book {self.book_id}>'

    def get_recommendation_ids(self):
        """Convert the stored string to a list of IDs"""
        if not self.recommendation_ids:
            return []
        return [int(id) for id in self.recommendation_ids.split(',')]
