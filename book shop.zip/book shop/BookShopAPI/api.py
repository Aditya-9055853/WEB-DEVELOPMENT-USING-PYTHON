import logging
import requests
import json
from flask import current_app
from models import Book
from sqlalchemy import or_

def search_google_books(query, max_results=10):
    """
    Search for books using Google Books API
    
    Args:
        query: Search query string
        max_results: Maximum number of results to return
        
    Returns:
        List of book dictionaries or empty list on failure
    """
    api_key = current_app.config.get('GOOGLE_BOOKS_API_KEY')
    base_url = "https://www.googleapis.com/books/v1/volumes"
    
    params = {
        'q': query,
        'maxResults': max_results,
        'key': api_key
    }
    
    try:
        response = requests.get(base_url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        
        books = []
        if 'items' in data:
            for item in data['items']:
                book = parse_google_book(item)
                if book:
                    books.append(book)
        
        return books
    except requests.RequestException as e:
        logging.error(f"Google Books API search error: {e}")
        return []


def get_book_details(book_id):
    """
    Get detailed information about a specific book from Google Books API
    
    Args:
        book_id: Google Books volume ID
        
    Returns:
        Book dictionary or None on failure
    """
    api_key = current_app.config.get('GOOGLE_BOOKS_API_KEY')
    url = f"https://www.googleapis.com/books/v1/volumes/{book_id}"
    
    params = {'key': api_key}
    
    try:
        response = requests.get(url, params=params, timeout=5)
        response.raise_for_status()
        item = response.json()
        
        return parse_google_book(item)
    except requests.RequestException as e:
        logging.error(f"Google Books API details error: {e}")
        return None


def parse_google_book(item):
    """
    Parse a Google Books API response item into a standardized book dictionary
    
    Args:
        item: Google Books API item
        
    Returns:
        Standardized book dictionary
    """
    if not item or 'id' not in item:
        return None
    
    volume_info = item.get('volumeInfo', {})
    
    # Extract ISBN if available
    isbn = ''
    industry_identifiers = volume_info.get('industryIdentifiers', [])
    for identifier in industry_identifiers:
        if identifier.get('type') in ('ISBN_13', 'ISBN_10'):
            isbn = identifier.get('identifier', '')
            break
    
    # Extract image URL
    thumbnail_url = ''
    image_links = volume_info.get('imageLinks', {})
    if image_links:
        thumbnail_url = image_links.get('thumbnail', '')
        # Convert to HTTPS if needed
        if thumbnail_url.startswith('http:'):
            thumbnail_url = 'https:' + thumbnail_url[5:]
    
    # Extract authors
    authors = volume_info.get('authors', [])
    authors_str = ', '.join(authors) if authors else ''
    
    # Extract categories
    categories = volume_info.get('categories', [])
    categories_str = ', '.join(categories) if categories else ''
    
    book = {
        'id': item.get('id'),
        'title': volume_info.get('title', 'Unknown Title'),
        'authors': authors_str,
        'publisher': volume_info.get('publisher', ''),
        'published_date': volume_info.get('publishedDate', ''),
        'description': volume_info.get('description', ''),
        'isbn': isbn,
        'page_count': volume_info.get('pageCount', 0),
        'categories': categories_str,
        'thumbnail_url': thumbnail_url,
        'price': 9.99,  # Default price since Google Books API doesn't provide pricing
        'stock': 0      # Default stock (0 means not available in our store yet)
    }
    
    return book


def search_local_books(query):
    """
    Search for books in the local database
    
    Args:
        query: Search query string
        
    Returns:
        List of Book objects matching the query
    """
    search_term = f"%{query}%"
    books = Book.query.filter(
        or_(
            Book.title.ilike(search_term),
            Book.authors.ilike(search_term),
            Book.publisher.ilike(search_term),
            Book.categories.ilike(search_term),
            Book.isbn.ilike(search_term)
        )
    ).all()
    
    return books


def get_book_recommendations(book_data, max_recommendations=6):
    """
    Get book recommendations based on a book
    
    This function can be implemented to use various recommendation APIs.
    For now, we'll implement a simple solution that gets similar books by category or author.
    
    Args:
        book_data: Book dictionary or Book object
        max_recommendations: Maximum number of recommendations to return
        
    Returns:
        List of recommended Book objects
    """
    # Get book attributes for matching
    if isinstance(book_data, dict):
        # For API-provided books
        book_id = book_data.get('id', 0)
        categories = book_data.get('categories', '')
        authors = book_data.get('authors', '')
    else:
        # For database Book objects
        book_id = book_data.id
        categories = book_data.categories
        authors = book_data.authors
    
    # First try to get recommendations based on category
    if categories:
        category_search = f"%{categories.split(',')[0].strip()}%"
        recommendations = Book.query.filter(
            Book.categories.ilike(category_search),
            Book.id != book_id
        ).limit(max_recommendations).all()
        
        if len(recommendations) >= max_recommendations:
            return recommendations
    
    # If not enough recommendations, add recommendations based on author
    if authors and len(recommendations) < max_recommendations:
        author_search = f"%{authors.split(',')[0].strip()}%"
        author_recommendations = Book.query.filter(
            Book.authors.ilike(author_search),
            Book.id != book_id
        ).limit(max_recommendations - len(recommendations)).all()
        
        # Add unique recommendations
        existing_ids = [book.id for book in recommendations]
        for book in author_recommendations:
            if book.id not in existing_ids:
                recommendations.append(book)
                existing_ids.append(book.id)
                
                if len(recommendations) >= max_recommendations:
                    break
    
    # If still not enough, get some random books
    if len(recommendations) < max_recommendations:
        random_books = Book.query.filter(
            Book.id != book_id
        ).order_by(Book.id.desc()).limit(max_recommendations - len(recommendations)).all()
        
        # Add unique recommendations
        existing_ids = [book.id for book in recommendations]
        for book in random_books:
            if book.id not in existing_ids:
                recommendations.append(book)
                existing_ids.append(book.id)
    
    return recommendations


def get_external_recommendations(book_id, api_key=None):
    """
    Get book recommendations from an external recommendation API
    
    Note: This is a placeholder for an external recommendation API integration.
    Replace with an actual API when available.
    
    Args:
        book_id: Book ID to get recommendations for
        api_key: API key for the recommendations service
        
    Returns:
        List of book IDs or empty list on failure
    """
    # This is where you would implement the actual external API call
    # For now, we'll return an empty list as a placeholder
    logging.info(f"External recommendation API call for book {book_id} would happen here")
    return []
