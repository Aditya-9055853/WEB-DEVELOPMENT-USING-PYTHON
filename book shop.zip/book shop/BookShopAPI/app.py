import os
import logging
import redis
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager


class Base(DeclarativeBase):
    pass


# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Create the Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # needed for url_for to generate with https

# Configure the database
# Use SQLite for local development if DATABASE_URL is not provided
database_url = os.environ.get("DATABASE_URL")
if not database_url:
    # If running locally without DATABASE_URL, use SQLite
    basedir = os.path.abspath(os.path.dirname(__file__))
    database_url = f"sqlite:///{os.path.join(basedir, 'bookshop.db')}"
    logging.info(f"Using SQLite database: {database_url}")

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# API keys
app.config["GOOGLE_BOOKS_API_KEY"] = os.environ.get("GOOGLE_BOOKS_API_KEY", "")
app.config["STRIPE_SECRET_KEY"] = os.environ.get("STRIPE_SECRET_KEY", "")
app.config["STRIPE_PUBLISHABLE_KEY"] = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
app.config["BOOK_RECOMMENDATIONS_API_KEY"] = os.environ.get("BOOK_RECOMMENDATIONS_API_KEY", "")

# Configure Redis for caching (optional)
redis_url = os.environ.get('REDIS_URL')
if redis_url:
    try:
        app.config['REDIS_CLIENT'] = redis.from_url(redis_url)
        logging.info("Redis connected successfully")
    except Exception as e:
        logging.error(f"Redis connection failed: {e}")
        app.config['REDIS_CLIENT'] = None
else:
    logging.info("Redis not configured, caching disabled")
    app.config['REDIS_CLIENT'] = None
    app.config['REDIS_ENABLED'] = False

# Initialize Flask extensions
db.init_app(app)

# Set up Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import models after db initialization to avoid circular imports
with app.app_context():
    import models  # noqa: F401
    # Create all database tables
    db.create_all()
    
    # Seed the database with initial data if empty
    try:
        from seed_data import seed_admin_user, seed_sample_books
        
        # Check if we have any books in the database
        from models import Book
        book_count = Book.query.count()
        
        if book_count == 0:
            logging.info("No books found in database. Running seed data functions...")
            seed_admin_user()
            seed_sample_books()
        else:
            logging.info(f"Database already contains {book_count} books. Skipping seed.")
    except Exception as e:
        logging.error(f"Error seeding database: {e}")
        # Continue with app startup even if seeding fails

# Configure the login manager to load users
from models import User

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
