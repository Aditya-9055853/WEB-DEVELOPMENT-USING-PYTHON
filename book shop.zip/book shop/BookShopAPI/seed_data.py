import os
import logging
from app import app, db
from models import User, Book, CartItem, Order
from werkzeug.security import generate_password_hash
from api import search_google_books, get_book_details

def seed_admin_user():
    """Create an admin user if it doesn't exist"""
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        try:
            admin = User(
                username='admin',
                email='admin@example.com',
                is_admin=True
            )
            admin.set_password('adminpassword')
            db.session.add(admin)
            db.session.commit()
            print("Created admin user")
        except Exception as e:
            db.session.rollback()
            print(f"Error creating admin user: {e}")

def seed_sample_books():
    """Add sample books to the database"""
    # Only seed if there are no books
    existing_books = Book.query.count()
    if existing_books > 0:
        print(f"Database already has {existing_books} books. Skipping book seeding.")
        return
    
    total_added = 0
    
    # Try to get books from Google Books API first
    try:
        # Popular book search queries to get a variety of books
        sample_searches = [
            "Harry Potter", 
            "Lord of the Rings",
            "The Great Gatsby",
            "To Kill a Mockingbird",
            "1984 George Orwell",
            "Pride and Prejudice"
        ]
        
        for query in sample_searches:
            try:
                # Get book results from Google Books API
                print(f"Searching for '{query}'...")
                books = search_google_books(query, max_results=2)  # Limit to 2 books per query
                
                if not books:
                    print(f"No results found for '{query}'")
                    continue
                    
                for book_data in books:
                    # Get detailed info for this book
                    book_id = book_data.get('id')
                    if not book_id:
                        continue
                        
                    # Check if book already exists
                    existing = Book.query.filter_by(google_books_id=book_id).first()
                    if existing:
                        print(f"Book '{book_data.get('title')}' already exists")
                        continue
                    
                    # Get full details
                    details = get_book_details(book_id)
                    if not details:
                        continue
                        
                    # Create book with random price and stock
                    import random
                    price = round(random.uniform(9.99, 29.99), 2)
                    stock = random.randint(5, 20)
                    
                    book = Book(
                        google_books_id=book_id,
                        title=details.get('title', 'Unknown Title'),
                        authors=details.get('authors', ''),
                        publisher=details.get('publisher', ''),
                        published_date=details.get('published_date', ''),
                        description=details.get('description', ''),
                        isbn=details.get('isbn', ''),
                        page_count=details.get('page_count', 0),
                        categories=details.get('categories', ''),
                        thumbnail_url=details.get('thumbnail_url', ''),
                        price=price,
                        stock=stock
                    )
                    
                    db.session.add(book)
                    db.session.commit()
                    total_added += 1
                    print(f"Added book: {book.title} (${book.price}, {book.stock} in stock)")
                    
            except Exception as e:
                db.session.rollback()
                print(f"Error adding books from '{query}': {e}")
    
    except Exception as e:
        print(f"Error using Google Books API: {e}")
        
    # If no books were added via API, add fallback books
    if total_added == 0:
        print("No books added from API. Adding fallback books...")
        
        # Hard-coded fallback books in case API fails
        fallback_books = [
            {
                "google_books_id": "fallback1",
                "title": "The Adventures of Sherlock Holmes",
                "authors": "Arthur Conan Doyle",
                "publisher": "Strand Magazine",
                "published_date": "1892",
                "description": "A collection of twelve short stories featuring the famous detective Sherlock Holmes and his friend Dr. Watson.",
                "isbn": "9780755398683",
                "page_count": 307,
                "categories": "Fiction, Mystery",
                "thumbnail_url": "https://books.google.com/books/content?id=3fSoBgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                "price": 12.99,
                "stock": 15
            },
            {
                "google_books_id": "fallback2",
                "title": "Pride and Prejudice",
                "authors": "Jane Austen",
                "publisher": "T. Egerton, Whitehall",
                "published_date": "1813",
                "description": "Pride and Prejudice is a romantic novel by Jane Austen, first published in 1813. The story follows the main character, Elizabeth Bennet, as she deals with issues of manners, upbringing, morality, education, and marriage in the society of the landed gentry of the British Regency.",
                "isbn": "9780141439518",
                "page_count": 432,
                "categories": "Fiction, Romance, Classic",
                "thumbnail_url": "https://books.google.com/books/content?id=s1gVAAAAYAAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                "price": 10.99,
                "stock": 8
            },
            {
                "google_books_id": "fallback3",
                "title": "To Kill a Mockingbird",
                "authors": "Harper Lee",
                "publisher": "J. B. Lippincott & Co.",
                "published_date": "1960",
                "description": "To Kill a Mockingbird is a novel by Harper Lee published in 1960. It was immediately successful, winning the Pulitzer Prize, and has become a classic of modern American literature.",
                "isbn": "9780060935467",
                "page_count": 336,
                "categories": "Fiction, Historical, Coming-of-age",
                "thumbnail_url": "https://books.google.com/books/content?id=PGR2AwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                "price": 14.99,
                "stock": 12
            },
            {
                "google_books_id": "fallback4",
                "title": "1984",
                "authors": "George Orwell",
                "publisher": "Secker & Warburg",
                "published_date": "1949",
                "description": "1984 is a dystopian novel by English novelist George Orwell. It was published in June 1949 by Secker & Warburg as Orwell's ninth and final book completed in his lifetime.",
                "isbn": "9780451524935",
                "page_count": 328,
                "categories": "Fiction, Science Fiction, Dystopian",
                "thumbnail_url": "https://books.google.com/books/content?id=kotPYEqx7kMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                "price": 11.99,
                "stock": 18
            },
            {
                "google_books_id": "fallback5",
                "title": "The Great Gatsby",
                "authors": "F. Scott Fitzgerald",
                "publisher": "Charles Scribner's Sons",
                "published_date": "1925",
                "description": "The Great Gatsby is a 1925 novel written by American author F. Scott Fitzgerald that follows a cast of characters living in the fictional towns of West Egg and East Egg on prosperous Long Island in the summer of 1922.",
                "isbn": "9780743273565",
                "page_count": 180,
                "categories": "Fiction, Literary Fiction",
                "thumbnail_url": "https://books.google.com/books/content?id=5VyoJQAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api",
                "price": 9.99,
                "stock": 7
            },
            {
                "google_books_id": "fallback6",
                "title": "The Lord of the Rings",
                "authors": "J. R. R. Tolkien",
                "publisher": "Allen & Unwin",
                "published_date": "1954",
                "description": "The Lord of the Rings is an epic high-fantasy novel written by English author and scholar J. R. R. Tolkien. The story began as a sequel to Tolkien's 1937 fantasy novel The Hobbit, but eventually developed into a much larger work.",
                "isbn": "9780618640157",
                "page_count": 1137,
                "categories": "Fiction, Fantasy",
                "thumbnail_url": "https://books.google.com/books/content?id=0v8nAgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api",
                "price": 24.99,
                "stock": 10
            }
        ]
        
        for book_data in fallback_books:
            try:
                book = Book(**book_data)
                db.session.add(book)
                db.session.commit()
                total_added += 1
                print(f"Added fallback book: {book.title}")
            except Exception as e:
                db.session.rollback()
                print(f"Error adding fallback book '{book_data['title']}': {e}")
    
    print(f"Finished seeding {total_added} books")

if __name__ == "__main__":
    with app.app_context():
        seed_admin_user()
        seed_sample_books()