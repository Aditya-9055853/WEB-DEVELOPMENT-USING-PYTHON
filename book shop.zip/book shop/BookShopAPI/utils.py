from models import CartItem, Book
from sqlalchemy.exc import SQLAlchemyError
import logging

def calculate_cart_total(user_id):
    """
    Calculate the total price of items in a user's cart
    
    Args:
        user_id: User ID whose cart to calculate
        
    Returns:
        Total price as float
    """
    total = 0.0
    cart_items = CartItem.query.filter_by(user_id=user_id).all()
    
    for item in cart_items:
        book = item.book
        if book:
            total += book.price * item.quantity
    
    return total


def validate_book_data(book_data):
    """
    Validate book data from external APIs
    
    Args:
        book_data: Dictionary of book data
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not book_data:
        return False, "No book data provided"
    
    required_fields = ['title']
    for field in required_fields:
        if field not in book_data or not book_data[field]:
            return False, f"Missing required field: {field}"
    
    return True, ""


def normalize_isbn(isbn):
    """
    Normalize ISBN by removing hyphens and whitespace
    
    Args:
        isbn: ISBN string
        
    Returns:
        Normalized ISBN string
    """
    if not isbn:
        return ""
    
    # Remove non-alphanumeric characters
    normalized = ''.join(c for c in isbn if c.isalnum())
    return normalized


def sync_inventory(book_id, new_stock):
    """
    Update the stock of a book in the inventory
    
    Args:
        book_id: Book ID to update
        new_stock: New stock quantity
        
    Returns:
        Boolean indicating success
    """
    try:
        book = Book.query.get(book_id)
        if not book:
            return False
        
        book.stock = new_stock
        db.session.commit()
        return True
    except SQLAlchemyError as e:
        db.session.rollback()
        logging.error(f"Error updating book inventory: {e}")
        return False


def format_price(price):
    """
    Format a price value to a string with 2 decimal places
    
    Args:
        price: Price as float
        
    Returns:
        Formatted price string
    """
    return f"${price:.2f}"


def book_to_dict(book):
    """
    Convert a Book model to a dictionary
    
    Args:
        book: Book model instance
        
    Returns:
        Dictionary representation of the book
    """
    if not book:
        return {}
    
    return {
        'id': book.id,
        'google_books_id': book.google_books_id,
        'title': book.title,
        'authors': book.authors,
        'publisher': book.publisher,
        'published_date': book.published_date,
        'description': book.description,
        'isbn': book.isbn,
        'page_count': book.page_count,
        'categories': book.categories,
        'thumbnail_url': book.thumbnail_url,
        'price': book.price,
        'stock': book.stock
    }
