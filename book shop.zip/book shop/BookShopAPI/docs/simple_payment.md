# Simple Pay-on-Delivery Payment System

This document explains the simple payment system implemented in the BookShop application, designed to be easily understood by first-year students.

## Overview

The Pay-on-Delivery system is a straightforward payment method that allows customers to place orders without providing payment information upfront. Instead, they pay when their order is delivered.

## Implementation Details

### 1. Route Handler

The payment process is handled by two main route functions:

- `create_pay_on_delivery_order()`: Processes the order and redirects to the success page
- `simple_payment_success()`: Displays the order confirmation

### 2. Database Models

The system uses these database models:

- `Order`: Stores order information with status "confirmed"
- `OrderItem`: Stores the books in the order
- `CartItem`: Temporary storage of items before checkout (cleared after order is created)

### 3. Order Processing

When a user clicks "Pay on Delivery":

1. The system retrieves all items from the user's cart
2. A new order is created with status "confirmed"
3. Order items are created for each book
4. The user's cart is cleared
5. The user is redirected to a success page

### 4. Templates

- `checkout.html`: Contains the "Pay on Delivery" button
- `simple_success.html`: Confirmation page with delivery instructions

## Benefits of This Approach

1. **Simplicity**: No external API integration required
2. **Educational Value**: Easy to understand for beginners
3. **No Security Concerns**: No payment information is processed or stored
4. **Full Control**: All code is contained within the application

## Code Example

```python
@app.route('/create_pay_on_delivery_order', methods=['POST'])
@login_required
def create_pay_on_delivery_order():
    """Create a simple pay-on-delivery order"""
    # Get cart items
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    
    # Calculate total
    total = calculate_cart_total(current_user.id)
    
    # Create order in the database
    order = Order(
        user_id=current_user.id,
        total_amount=total,
        status='confirmed'  # directly mark as confirmed
    )
    db.session.add(order)
    db.session.commit()
    
    # Create order items
    for item in cart_items:
        order_item = OrderItem(
            order_id=order.id,
            book_id=item.book_id,
            quantity=item.quantity,
            price=item.book.price
        )
        db.session.add(order_item)
    
    # Clear the user's cart
    CartItem.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    
    # Redirect to success page
    return redirect(url_for('simple_payment_success', order_id=order.id))
```

## Future Enhancements

For more advanced students, the system could be enhanced with:

1. Email notifications
2. Address validation
3. Admin dashboard for order fulfillment
4. Order tracking

## Conclusion

This simple payment system demonstrates core concepts of e-commerce applications without the complexity of external payment gateways. It's ideal for educational purposes and provides a solid foundation for learning more advanced concepts.