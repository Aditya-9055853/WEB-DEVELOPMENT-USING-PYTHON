# Running BookShop Application Locally

This guide explains how to run the BookShop application in your local environment.

## Prerequisites

- Python 3.7 or higher
- pip (Python package installer)

## Installation

1. Clone or download this repository to your local machine
2. Navigate to the project directory in your terminal/command prompt
3. Install the required dependencies:

```bash
pip install -r docs/requirements.txt
```

Or install them individually:

```bash
pip install flask flask-login flask-sqlalchemy email-validator gunicorn psycopg2-binary redis stripe
```

## Configuration Options

The application supports multiple configuration options through environment variables. All of these are optional as the app provides sensible defaults:

### Database Configuration

By default, the application uses SQLite for local development, which doesn't require any configuration. If you want to use PostgreSQL or another database, set the following environment variable:

- `DATABASE_URL`: Database connection URL (e.g., `postgresql://username:password@localhost:5432/bookshop`)

### Redis Configuration (Optional)

Redis is used for caching but is optional. The application works fine without Redis:

- `REDIS_URL`: Redis connection URL (e.g., `redis://localhost:6379/0`)

### Other Configuration

- `SESSION_SECRET`: Secret key for session management (default: a development secret)
- `GOOGLE_BOOKS_API_KEY`: API key for Google Books (optional)
- `STRIPE_SECRET_KEY` and `STRIPE_PUBLISHABLE_KEY`: Stripe API keys (only needed if using Stripe payments)

## Running the Application

### Using Python directly

```bash
python main.py
```

### Using Gunicorn (recommended for production-like environment)

```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## Accessing the Application

Once running, access the application in your web browser:

- http://localhost:5000

## Troubleshooting

### Database Issues

If you encounter database-related errors:

1. Check if your database server is running (if using PostgreSQL or MySQL)
2. Verify the DATABASE_URL environment variable is correctly set
3. If all else fails, delete the `bookshop.db` file to reset the SQLite database

### Redis Issues

If you encounter Redis-related errors:

1. Redis is optional, so the application will work without it
2. To use Redis, ensure the Redis server is running
3. Set the REDIS_URL environment variable correctly

### Authentication Issues

The default admin account is:
- Username: admin
- Password: adminpassword

If you can't log in, try resetting the database as mentioned above.
