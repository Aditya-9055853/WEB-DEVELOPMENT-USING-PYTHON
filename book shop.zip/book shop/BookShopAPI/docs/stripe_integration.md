# Stripe Integration Documentation for BookShop

This document provides a comprehensive guide to how Stripe payment processing has been integrated into the BookShop application.

## Overview

The BookShop application uses Stripe's hosted checkout page to securely process payments. This approach is more secure as payment details are handled directly by Stripe and not by our application.

## Key Files

The Stripe integration involves these key files:

1. **app.py** - Configures the Stripe API keys from environment variables
2. **routes.py** - Contains the payment flow logic
3. **templates/checkout.html** - The page that initiates the checkout process
4. **templates/success.html** - Displayed after successful payment
5. **templates/cancel.html** - Displayed if checkout is cancelled

## Configuration

Stripe requires two API keys:

- **STRIPE_SECRET_KEY** - Used server-side to create checkout sessions, verify payments, etc.
- **STRIPE_PUBLISHABLE_KEY** - Used client-side for public operations

These keys are stored securely as environment variables and accessed in `app.py`:

```python
app.config["STRIPE_SECRET_KEY"] = os.environ.get("STRIPE_SECRET_KEY", "")
app.config["STRIPE_PUBLISHABLE_KEY"] = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
```

## Checkout Flow

1. **Cart to Checkout**: User adds items to cart and proceeds to checkout page

2. **Initiate Checkout**: On the checkout page, the user clicks "Pay with Stripe":
   ```html
   <form action="{{ url_for('create_checkout_session') }}" method="post">
       <button type="submit" class="btn btn-success btn-lg w-100">
           <i class="fas fa-lock me-2"></i> Pay with Stripe
       </button>
   </form>
   ```

3. **Create Checkout Session**: The application creates a Stripe checkout session:
   ```python
   @app.route('/create-checkout-session', methods=['POST'])
   @login_required
   def create_checkout_session():
       # Get cart items and prepare line items for Stripe
       line_items = []
       for item in cart_items:
           line_items.append({
               'price_data': {
                   'currency': 'usd',
                   'product_data': {
                       'name': book.title,
                       # Additional product details
                   },
                   'unit_amount': int(book.price * 100),  # Convert to cents
               },
               'quantity': item.quantity,
           })
       
       # Create a pending order in the database
       order = Order(user_id=current_user.id, total_amount=total, status='pending')
       
       # Create the Stripe checkout session
       checkout_session = stripe.checkout.Session.create(
           payment_method_types=['card'],
           line_items=line_items,
           mode='payment',
           success_url=YOUR_DOMAIN + url_for('checkout_success') + f'?session_id={{CHECKOUT_SESSION_ID}}&order_id={order.id}',
           cancel_url=YOUR_DOMAIN + url_for('checkout_cancel') + f'?order_id={order.id}',
           # Additional parameters
       )
       
       # Redirect to Stripe's hosted checkout page
       return redirect(checkout_session.url, code=303)
   ```

4. **Process Payment**: The user enters their payment details on Stripe's secure page

5. **Payment Success**: After successful payment, the user is redirected to the success URL:
   ```python
   @app.route('/checkout/success')
   @login_required
   def checkout_success():
       # Verify the payment with Stripe
       checkout_session = stripe.checkout.Session.retrieve(session_id)
       
       if checkout_session.payment_status == 'paid':
           # Update order status, reduce inventory, clear cart
           order.status = 'paid'
           order.stripe_payment_id = checkout_session.payment_intent
           # Additional processing
       
       return render_template('success.html', order=order)
   ```

6. **Payment Cancellation**: If the user cancels, they are redirected to the cancel URL:
   ```python
   @app.route('/checkout/cancel')
   @login_required
   def checkout_cancel():
       # Mark order as cancelled if it exists
       if order_id:
           order = Order.query.filter_by(id=order_id, user_id=current_user.id).first()
           if order and order.status == 'pending':
               order.status = 'cancelled'
       
       return render_template('cancel.html')
   ```

## Database Integration

The application uses several models to track orders and payments:

- **Order**: Stores the overall order with status and payment IDs
- **OrderItem**: Stores individual books in an order
- **CartItem**: Temporary storage of items before checkout

When a payment is successful, the application:
1. Updates the order status to 'paid'
2. Stores the Stripe payment intent ID
3. Updates book inventory (reduces stock)
4. Clears the user's shopping cart

## Testing the Integration

For testing purposes, you can use Stripe's test cards:

- Success: 4242 4242 4242 4242
- Declined: 4000 0000 0000 0002
- Expiration date: Any future date
- CVC: Any 3 digits
- Postal code: Any postal code

## Troubleshooting

Common issues:
1. API key errors - Ensure both secret and publishable keys are set
2. Invalid line items - Check that price is positive and converted to cents
3. URL issues - Ensure success and cancel URLs are properly formatted

## Resources

- [Stripe API Documentation](https://stripe.com/docs/api)
- [Stripe Checkout Guide](https://stripe.com/docs/payments/checkout)
- [Stripe Testing](https://stripe.com/docs/testing)